/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RideShareDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

public class DbRepo {
   

    public static CachedRowSet getConfiguredConnection() {
        CachedRowSet crs = null;
        try {
        Class.forName("com.mysql.jdbc.Driver");
        crs = RowSetProvider.newFactory().createCachedRowSet();
        crs.setUrl("jdbc:mysql://localhost:3306/rideshare");
        crs.setUsername("root");
        crs.setPassword("");
        } catch (SQLException ex) {
            Logger.getLogger(DbRepo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DbRepo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return crs; 
    }
}

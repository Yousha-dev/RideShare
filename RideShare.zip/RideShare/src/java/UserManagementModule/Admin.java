/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserManagementModule;

import DriverRideManagementModule.Car;
import DriverRideManagementModule.Driver;
import PassengerRideManagementModule.Passenger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.rowset.CachedRowSet;


public class Admin extends User {

    public static boolean isAdmin(String emailID) throws SQLException {
        CachedRowSet crs = RideShareDatabase.DbRepo.getConfiguredConnection();
        crs.setCommand("Select * from ADMINS WHERE ADM_EMAIL_ID = ? ");
        crs.setString(1, emailID);
        crs.execute();
        //If there is a record
        if (crs.next()) {
            return true;
        } else {
            return false;
        }
    }

    //retrieveDriverRequests (then to display to user)
    //select driver call passenger class
    public static ArrayList<Driver> retriveDriverRequests() throws SQLException {

        ArrayList<Driver> drivers = new ArrayList<>();
        CachedRowSet crs = RideShareDatabase.DbRepo.getConfiguredConnection();
        crs.setCommand("SELECT email_id, car_model, car_capacity FROM DRIVER_APPLICATIONS where email_id NOT IN (select driver_id from drivers)");

        crs.execute();
        while (crs.next()) {
            Driver currDriver = new Driver();
            currDriver.setEmailID(crs.getString("email_id"));
            Car c = new Car(crs.getString("car_model"), crs.getInt("car_capacity"));
            currDriver.setMyCar(c);
            drivers.add(currDriver);
        }
        return drivers;
    }

    public static void acceptDriverRequest(String Driver_ID) {
        Driver d = new Driver();
        d.setEmailID(Driver_ID);
        try {
            d.makeDriver();
        } catch (SQLException ex) {
            Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void rejectDriverRequest(String Driver_ID) {
        Driver d = new Driver();
        d.setEmailID(Driver_ID);
        try {
           d.rejectDriverRequest();
        } catch (SQLException ex) {
            Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
